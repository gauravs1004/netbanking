<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost:8808";
    $db="internetbanking_db";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);

    if ($mysqli->connect_error) {

        die("". $mysqli->connect_error);

    }

        ?>php